
// 本地测试地址
const HOST = "http://192.168.1.242:8088/";
const GAME_HOST = "https://192.168.1.241:8081/";
// 香港
// const HOST = "https://hk-shop.winbet888.net/";
// const GAME_HOST = "https://hk-gw.winbet888.net:8081/";
// 新加坡
// const HOST = "https://sg-shop.winbet888.net/";
// const GAME_HOST = "https://winbet888.net:8081/";

let PRICE = 0;
let COUNT = 0;
export default {
    HOST,
    GAME_HOST,
    PRICE,
    COUNT
}
