<template>
    <div class="page-list">
        <div class="nav-row">
            <van-nav-bar left-arrow fixed z-index="10" class="nav" :border="false">
                <template #title>
                    <span class="title">VIP榜单</span>
                </template>
                <template #left>
                    <span
                        style="
                        font-size:14px;
                        text-align: center;
                        display:inline-block;
                        width:23px;
                        height:23px;
                        line-height:26px;
                        border-radius:50%
                        color: #B8CCEF;
                        background-color: #21263B;"
                        @click="$router.go(-1)"
                    ><van-icon name="arrow-left" color="#fff" /></span>
                </template>
            </van-nav-bar>
        </div>
        <div class="list-content">
            <div class="row">
                <div class="image">
                    <van-image width="50" height="50" round src="https://img.yzcdn.cn/vant/cat.jpeg" />
                </div>
                <div class="textContext">
                    <div
                        class="text van-ellipsis"
                    >
                    Apple iPhone XR 128<van-image width="20" height="10" round src="https://img.yzcdn.cn/vant/cat.jpeg" />
                    </div>
                    <div class="desc">
                        9,988 竞猜币
                    </div>
                </div>
                <div class="num">
                    <van-image width="60" height="60" round src="https://img.yzcdn.cn/vant/cat.jpeg" />
                </div>
            </div>
            <div class="row">
                <div class="image">
                    <van-image width="50" height="50" round src="https://img.yzcdn.cn/vant/cat.jpeg" />
                </div>
                <div class="textContext">
                    <div
                        class="text van-ellipsis"
                    >
                    Apple iPhone XR 128<van-image width="20" height="10" round src="https://img.yzcdn.cn/vant/cat.jpeg" />
                    </div>
                    <div class="desc">
                        9,988 竞猜币
                    </div>
                </div>
                <div class="num">
                    <van-image width="60" height="60" round src="https://img.yzcdn.cn/vant/cat.jpeg" />
                </div>
            </div>
        </div>
    </div>
    
</template>

<script>
// import Vue from 'vue';
// import { Toast} from "vant";
export default {
    data() {
        return {
            // current: 0
        };
    },
    methods: {

    }
};
</script>
<style scoped>
.page-list .nav-row .nav {
    color: #ffffff;
    background-color: #090c15;
}
.page-list .nav-row .nav .title {
    color: #BACEF1 !important;
}
/* 列表内容 */
.page-list .list-content{
    padding: 46px 0 0 0;
}


.page-list .row {
  display: flex;
  align-items: center;
  overflow: hidden;
  /* margin: 0 12px; */
  box-sizing: border-box;
  padding: 15px 12px;
  border-bottom: 1px solid #10182A;
}
.page-list .row .image img{
    border-radius: 50%;
}
.page-list .row .textContext {
    /* max-width: 58%; */
    flex: 1;
    overflow: hidden;
}
.page-list .row .textContext .text {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  font-size: 14px;
  color: #ececed;
  width: 100%;
  /* height; */
}
.page-list .row .textContext .desc {
  font-size: 12px;
  color: #36445B;
}
.page-list .row .textContext .text,
.page-list .row .textContext .desc {
  padding: 2px 10px 4px 8px;
}
.page-list .row .num{
    /* width: 30%; */
    color: #adc0e1;
    text-align: right;
    font-size: 12px;
} 
</style>
