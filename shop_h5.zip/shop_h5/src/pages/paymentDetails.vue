<template>
    <div class="page-paymentDetails">
        <component-header>
            <template #left>
                <img @click="$router.go(-1)" src="./../assets/images/icon_back.png" />
            </template>
            <template #title>
                {{ type == 'pay' ? '立即兑换' : '兑换详情' }}
            </template>
            <template #right>
                <img  @click="$router.push({path: 'exchangeRules'})" src="./../assets/images/xuanxuan-image.png" />
                <img @click="$router.push({path: 'customer'})" src="./../assets/images/headset.png" />
            </template>
        </component-header>
<!--        <div class="nav-row">-->
<!--            <van-nav-bar left-arrow fixed z-index="10" class="nav" :border="false">-->
<!--                <template #title>-->
<!--                    <span class="title">-->
<!--                        {{ type == 'pay' ? '立即支付' : '兑换详情' }}-->
<!--                    </span>-->
<!--                </template>-->
<!--                <template #left>-->
<!--                    <span-->
<!--                        style="-->
<!--                            font-size:14px;-->
<!--                            text-align: center;-->
<!--                            display:inline-block;-->
<!--                            width:23px;-->
<!--                            height:23px;-->
<!--                            line-height:26px;-->
<!--                            border-radius:50%-->
<!--                            color: #B8CCEF;-->
<!--                            background-color: #21263B;"-->
<!--                        @click="$router.go(-1)"-->
<!--                    ><van-icon name="arrow-left" color="#fff" /></span>-->
<!--                </template>-->
<!--            </van-nav-bar>-->
<!--        </div>-->
        
        <div class="content">
            <div class="row1" v-if="shopInfo.status == 0 && type == 'pay'">
                等待支付，订单将在 <van-count-down @change="onTimeData" :time="time" style="display: inline-block;color:#1bafff" /> 关闭
            </div>

            <div class="account" v-if="accountShow">
                <!-- 账号：{{shopInfo.account}} <van-icon color="#B9CDF0" name="edit" /> -->
                账号：<input :disabled="type != 'pay'" type="text" :class="{'pattern-account-style' : accountRequired}" placeholder="请输入账号，如QQ号、爱奇艺等" v-model="shopInfo.account" />
                <van-icon color="#B9CDF0" name="edit"  v-if="type == 'pay'" />
            </div>

            <div class="address" v-if="shopInfo.goods_type == 2">
                <div class="list">
                    <div class="name"><span style="color: #0386B6;padding-right:3px">*</span><span style="letter-spacing:4.5px;">收件人</span>：</div>
                    <div class="value"><input :disabled="true" type="text" :class="{'pattern-style' : address.name.pattern}" v-model="address.name.val" placeholder="请输入收件人名字" /></div>
                </div>
                <div class="list">
                    <div class="name"><span style="color: #0386B6;padding-right:3px">*</span><span style="letter-spacing:4.5px;">手机号</span>：</div>
                    <div class="value"><input :disabled="true" type="text" :class="{'pattern-style' : address.phone.pattern}" v-model="address.phone.val" placeholder="请输入收件人手机号" /></div>
                </div>
                <div class="list">
                     <div class="name"><span style="color: #0386B6;padding-right:3px">*</span>详细地址：</div>
                    <div class="value"><input :disabled="true" type="text" :class="{'pattern-style' : address.location.pattern}" v-model="address.location.val" placeholder="请输入收件人地址" /></div>
                </div>
            </div>

            <div class="row2">
                <div class="image">
                    <van-image width="50" height="50" :src="shopInfo.goods_thumb_img" />
                </div>
                <div class="textContext">
                    <div class="text van-ellipsis">{{shopInfo.goods_name}}</div>
                    <div class="desc">
                        {{utils.filterPrice(shopInfo.price)}} <span>竞猜币</span>
                    </div>
                </div>
                <div class="num">×1</div>
            </div>
            <div class="row3">
                <div class="left">商品总付</div>
                <div class="right"><span style="font-size: 15px;color:#1de7e7;font-family:'DIN'">{{utils.filterPrice(shopInfo.price)}}</span> 竞猜币</div>
            </div>
            <div class="row4" v-if="type != 'pay'">
                <div class="list">
                    <div class="left">订单号</div>
                    <div class="right">{{shopInfo.order_sn}} 
                        <span
                          v-clipboard:copy="shopInfo.order_sn"
                          v-clipboard:success="onCopy"
                          v-clipboard:error="onError"
                          style="color: #FFFFFF;padding: 0 0 0 15px"
                        ><van-image width="12" :src="require('../assets/images/Icon_copy_xiao.png')" /></span></div>
                </div>
                <div class="list">
                    <div class="left">创建时间</div>
                    <div class="right">{{shopInfo.created_at}}</div>
                </div>
                <div class="list">
                    <div class="left">支付时间</div>
                    <div class="right">{{shopInfo.pay_time}}</div>
                </div>
                <div class="list">
                    <div class="left">兑换状态</div>
                    <div class="right">
                        {{
                            shopInfo.status == 0 && "兑换中" ||
                            shopInfo.status == 1 && "待发货" ||
                            shopInfo.status == 2 && "已发货" || 
                            shopInfo.status == 3 && "已完成" ||
                            shopInfo.status == 4 && "已取消"
                        }}
                    </div>
                </div>
                <div class="list" v-if="shopInfo.goods_type == 2 && (shopInfo.status == 2 || shopInfo.status == 3)">
                    <div class="left">物流公司</div>
                    <div class="right">
                        
                        {{shopInfo.logistics_name}}
                    </div>
                </div>
                <div class="list" v-if="shopInfo.goods_type == 2 && (shopInfo.status == 2 || shopInfo.status == 3)">
                    <div class="left">物流单号</div>
                    <div class="right">
                        {{shopInfo.logistics_sn}}
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom" v-if="type == 'pay'">
            <van-goods-action>
                <div class="price"><span>{{utils.filterPrice(shopInfo.price)}}</span>竞猜币</div>
                <van-goods-action-button
                    text="立即兑换"
                    color="#1BAFFF"
                    @click="submitOrder"
                />
            </van-goods-action>
        </div>
    </div>
</template>

<script>
import Vue from 'vue';
import { Toast, Notify, CountDown  } from "vant";
import ComponentHeader from './../components/ComponentHeader';
import axios from 'axios';
Vue.use(Notify);
Vue.use(CountDown);
export default {
    components: {
        ComponentHeader
    },
    data() {
        return {
            shopInfo: {},
            address: {
                name: {
                    val: '',
                    pattern: false
                },
                phone: {
                    val: '',
                    pattern: false
                },
                location: {
                    val: '',
                    pattern: false
                }
            },
            time: 0,
            type: null,
            status: null,
            orderSn: '',
            accountShow: false,
            accountRequired: false,
            orderTime: false
        };
    },
    mounted() {
        let { order_sn, type, status } = this.$route.query;
        // 是否底部导航支付内容
        this.type = type;
        this.status = status;
        this.orderSn = order_sn;
        if (type == 'pay') {
            axios.post(this.config.HOST + "api/order/buy", {
                order_sn: order_sn,
            })
        }

        axios.post(this.config.HOST + "api/order/order_info", {
            order_sn: order_sn,
        })
        .then(response => {
            let result = response.data;
            if (result.code == 0) {
                let { data } = result;
                if (JSON.stringify(data) != "{}") {
                    this.shopInfo = data;
                    if (this.shopInfo && JSON.stringify(this.shopInfo) != '{}') {
                        // 赋值地址
                        this.address.name.val = this.shopInfo.receipt_name;
                        this.address.phone.val = this.shopInfo.receipt_mobile;
                        this.address.location.val = this.shopInfo.receipt_address;

                        // 是否有账号
                        if (this.shopInfo.account) {
                            this.accountShow = true;
                        }

                        if (this.shopInfo.created_at && this.shopInfo.status ==0) {
                            // 计算订单是否过期 
                            let orderDatetime = new Date(this.shopInfo.created_at);
                                orderDatetime.setMinutes(orderDatetime.getMinutes() + 30);
                                orderDatetime = orderDatetime.getTime();
                            let currentDatetime = new Date().getTime();
                            let datetime = orderDatetime - currentDatetime;
                            if (datetime <= 0) {
                                // 下单时间过期了
                                this.orderTime = false;
                            } else {
                                // let second = parseInt(datetime / 1000);
                                // let minute = Math.floor(second / 60);
                                this.time = datetime;
                                this.orderTime = true;
                            }
                        }
                    }
                } else {
                    this.shopInfo = null;
                }
            }
        });
    },
    created() {

    },
    methods: {
        onCopy() {
            Toast("复制成功!");
        },
        onError() {
            Toast("复制失败!");
        },
        onTimeData(timeDate) {
            if (timeDate.minutes<=0 && timeDate.minutes <= 0 && timeDate.milliseconds <= 0) {
                this.orderTime = false;
            } else {
                this.orderTime = true;
            }
        },
        /*
        onOrder() {
            if (!this.orderTime && this.shopInfo.status == 0) {
                // 订单已过期
                Toast({
                    message: '订单已过期',
                    icon: 'cross',
                    onOpened: () => {
                        this.$router.replace({ path: 'exchange' });
                    }
                });
                return;
            }

            this.submitOrder();

        },*/
        async submitOrder() {
            if (!this.orderTime && this.shopInfo.status == 0) {
                // 订单已过期
                Toast({
                    message: '订单已过期',
                    icon: 'cross',
                    onOpened: () => {
                        this.$router.replace({ path: 'exchange' });
                    }
                });
                return;
            }

            let isConfirm = false;
            let result = null;
            let isPay = false;
            let orderSn = '';

            //确定订单
            isConfirm = await this.confirmOrder();
            if (!isConfirm) {
                Toast({
                    message: '兑换失败',
                    icon: 'cross',
                    onOpened: () => {
                        this.$router.go(-1);
                    }
                });
                return;
            }

            if (this.status == 'againPay') {
                //创建订单
                result = await this.createOrder();
                if (!result) {
                    Toast({
                        message: '兑换失败',
                        icon: 'cross',
                        onOpened: () => {
                            this.$router.go(-1);
                        }
                    });
                    return;
                }
            }

            // 支付订单
            if (this.status == 'againPay') {
                orderSn = result.order_sn;
            } else {
                orderSn = this.orderSn;
            }
            isPay = await  this.payOrder(orderSn);
            if (isPay) {
                Toast({
                    message: '已兑换成功',
                    icon: require('../assets/images/popwindow.png'),
                    onOpened: () => {
                        this.$router.replace({ path: 'exchange' });
                    }
                });
            } else {
                Toast({
                    message: '兑换失败',
                    icon: 'cross',
                    onOpened: () => {
                        this.$router.replace({ path: 'exchange' });
                    }
                });
            }

        },
        confirmOrder() {
            return new Promise((resolve) => {
                axios.post(this.config.HOST + "api/order/confirm", {
                    goods_id: this.shopInfo.goods_id,
                    account: this.shopInfo.account
                })
                    .then(response => {
                        let result = response.data;
                        if (result.code == 0) {
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    });
            });
        },
        createOrder() {
            return new Promise((resolve) => {
                axios.post(this.config.HOST + "api/order/create", {
                    goods_id: this.shopInfo.goods_id,
                    account: this.shopInfo.account,
                    receipt_name: this.shopInfo.goods_type == 2 ? this.address.name.val : undefined,
                    receipt_mobile: this.shopInfo.goods_type == 2 ? this.address.phone.val : undefined,
                    receipt_address: this.shopInfo.goods_type == 2 ? this.address.location.val : undefined,
                })
                    .then(response => {
                        let result = response.data;
                        if (result.code == 0) {
                            resolve(result);
                        } else {
                            resolve(null);
                        }
                    });
            })
        },
        payOrder(order_sn) {
            return new Promise(resolve => {
                axios.post(this.config.HOST + "api/order/pay", {
                    order_sn: order_sn
                })
                    .then(response => {
                        let result = response.data;
                        if (result.code == 0) {
                            resolve(true);

                        } else {
                            resolve(false);
                        }
                    });
            });
        },
    }
};
</script>

<style lang="less" scoped>
.page-paymentDetails {
    // 导航
    .nav-row {
        .nav {
            top: 46px !important;
            color: #ffffff;
            background-color: #090c15;
            .title {
                color: #BACEF1 !important;
            }

        }
    }
    // 内容部分
    .content{
        /*padding: 46px 0 0 0;*/
        .row1 {
            color: #1bafff;
            text-align: center;
            padding: 14.5px 0;
            border-bottom: 1px solid #262f40;
            font-size: 14px;
        }
        /* 账号 */

        .account {
            background: #1D2538;
            padding: 8px 15px;
            font-size: 14px;
            color: #4D607D;
            display: flex;
            input {
                background-color: transparent;
                border: transparent;
                flex: 1;
                color: #ffffff;
            }
            input.pattern-account-style::-webkit-input-placeholder{
                color: red;
            }
        }

        /* 地址 */
        .address{
            display: flex;
            flex-direction: column;
            padding: 7.5px 15px;
            font-size: 16px;
            border-bottom: 1px solid #262f40;

            .list{
                display: flex;
                padding: 7.5px 0;
                .name {
                    color: #bacef1;
                }
                .value {
                    input {
                        border: 0;
                        background: transparent;
                        color: #ffffff;
                        padding: 3px 0px 3px 8px;
                        font-size: 14px
                    }
                    input::-webkit-input-placeholder {
                        color: #526583;
                        font-size: 14px
                    }
                    input.pattern-style::-webkit-input-placeholder {
                        color: red;
                    }
                }
            }
        }

        // 商品图片
        .row2 {
            display: flex;
            align-items: center;
            overflow: hidden;
            box-sizing: border-box;
            padding: 15px;
            border-bottom: 1px solid #192032;
            .image {
                background:none;
                img {
                    border-radius: 50%;
                }
            }
            .textContext {
                max-width: 90%;
                overflow: hidden;
                flex: 1;
                .text {
                    font-weight: bold;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    overflow: hidden;
                    font-size: 16px;
                    color: #ffffff;
                    font-weight: bold;
                    width: 100%;
                }
                .desc {
                    font-size: 14px;
                    font-family: 'DIN';
                    color: #bacef1;
                    span{
                        font-family: normal;
                        font-size: 13px;
                    }
                }
                .text,
                .desc {
                    padding: 5px 10px 5px 15px;
                }
                .text{
                    padding-top:0px;
                }
            }
            .num{
                width: 20%;
                color: #bacef1;
                text-align: right;
                font-size: 13px;
                font-weight: bold;
            }
        }
    }

    .row3 {
        display: flex;
        color: #bacef1;
        padding: 15px 15px;
        border-bottom: 1px solid #192032;
        .left {
            flex: 1;
            font-size: 14px;
            color: #becef1;
        }
        .right {
            font-size: 12px;
        }
    }
    
    .row4 {
        padding: 15px 12px 12px;
        font-size: 13px;
        .list{
            display: flex;
            padding: 0px 0 10px 0;
            color:#becef1;
            .left{
                flex: 1;
                color:#becef1;
            }
            .right{
                color:#4f6282;
            }
        }
    }

    /* 底部 */
    .bottom {
        .price {
            font-size: 13px;
            color: #bacef1;
            padding:0 0 0 15px;
            width: 60%;
            font-family: normal;
            span{
                font-size: 26px;
                font-family: 'DIN';
                margin-right: 5px;
            }
        }
        .van-goods-action {
            height: 44px;
            background-color: #363c53;
        }
        .van-goods-action-icon {
            background-color: #363c53;
            color: #B3C6E8;
        }
        .van-goods-action-button--last {
            border-radius: 0;
            height: 100%;
            margin: 0 0 0 5px;
            font-size: 15px;
            font-weight: bold;
        }
    }
}

</style>
