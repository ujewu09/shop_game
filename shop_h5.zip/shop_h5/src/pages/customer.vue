<template>
    <div class="page-customer">
        <component-header>
            <template #left>
                <img @click="goBack" src="./../assets/images/icon_back.png" />
            </template>
            <template #title>
                客服
            </template>
        </component-header>
        <div class="text-content">
            <iframe :src="url" v-bind:style="{height: maxHeight}" frameborder="0" class="iframe"  scrolling="auto">
            </iframe>
        </div>
    </div>
    
</template>

<script>
import Vue from 'vue';
import axios from 'axios';
import { Image as VanImage} from "vant";
import ComponentHeader from './../components/ComponentHeader';
Vue.use(VanImage);
export default {
    components: {
        ComponentHeader
    },
    data() {
        return {
            url: '',
            rlen: history.length,
            maxHeight: 0
        };
    },
    mounted(){
        
 var a=document.createElement("meta");
    var b=document.createElement("meta");
    a.httpEquiv = "X-Webkit-CSP";
    b.httpEquiv = "Content-Security-Policy";
    a.content = b.content = "upgrade-insecure-requests";
    if(location.protocol==='https:'){
        document.head.insertAdjacentElement('afterbegin',b);
        document.head.insertAdjacentElement('afterbegin',a);
    }

        if (sessionStorage.getItem("session")) {
            axios.post(this.config.GAME_HOST + 'api/v1/user/common_router', {
                group: 'workSrv',
                seq: 0,
                cmd: 'service_url',
                data: {
                    sessionId: sessionStorage.getItem("session")
                }
            }).then((response) => {
                console.log(response);
                let result = response;
                if (result.status == 200) {
                    let { data } = result;
                    if (data && data.code == 200) {
                        this.url = data.data.url;
                        this.maxHeight = (window.innerHeight - 49) + 'px';
                    }
                }
            });
        }
    },
    methods: {
        goBack() {
            let len = this.rlen - history.length - 1;//-1是不进入iframe页面的下级页面直接退出的话，执行后退一步的操作
            this.$router.go(len);
        }
    }
};
</script>
<style scoped lang="less">

.page-customer{
    .text-content{
        padding: 0px 0 0 0;
        background: #0C1220;
        .iframe {
            width: 100%;
            height: 100%;
        }
    }
}
</style>
