<template>
    <div class="page-payment">
        <component-header>
            <template #left>
                <img @click="backOrder" src="./../assets/images/icon_back.png" />
            </template>
            <template #title>
                立即兑换
            </template>
            <template #right>
                <img @click="$router.push({path: 'exchangeRules'})" src="./../assets/images/xuanxuan-image.png" />
                <img @click="$router.push({path: 'customer'})" src="./../assets/images/headset.png" />
            </template>
        </component-header>
<!--        <div class="nav-row">-->
<!--            <van-nav-bar left-arrow fixed z-index="10" class="nav" :border="false">-->
<!--                <template #title>-->
<!--                    <span class="title">立即支付</span>-->
<!--                </template>-->
<!--                <template #left>-->
<!--                    <span-->
<!--                        style="-->
<!--                            font-size:14px;-->
<!--                            text-align: center;-->
<!--                            display:inline-block;-->
<!--                            width:23px;-->
<!--                            height:23px;-->
<!--                            line-height:26px;-->
<!--                            border-radius:50%;-->
<!--                            color: #B8CCEF;-->
<!--                            background-color: #21263B;"-->
<!--                        @click="backOrder"-->
<!--                    ><van-icon name="arrow-left" color="#fff" /></span>-->
<!--                </template>-->
<!--            </van-nav-bar>-->
<!--        </div>-->

        <div class="content">
            <!-- <div class="row1">
                等待支付，订单将在 <van-count-down @change="onTimeData" :time="time" style="display: inline-block;color:#019DD4" /> 关闭
            </div> -->
             <div class="phoneError" v-if="phoneError">
                <img src="../assets/images/error.png"/> <span>手机号码有误，请重填</span> 
            </div>

            <div class="account" v-if="shopInfo.is_account == 1">
                <div class="editbox">
                    <i style="color:#1bafff;margin:5px 5px 0 0">*</i>账号
                    <div class="text" v-if="show"><span>{{shopInfo.account}}</span><img src="../assets/images/icon_edit.png" @click="show=false" /></div>
                    <div class="text" v-else><input v-model="account" /></div>
                </div>
                <!-- <van-icon color="#B9CDF0" name="edit" /> -->
            </div>
            
            <div class="address" v-if="shopInfo.goods_type == 2">
                <div class="list">
                    <div class="name"><span style="color: #0386B6;padding-right:3px">*</span><span style="letter-spacing:4.5px;">收件人</span>：</div>
                    <div class="value"><input ref="name" type="text" :class="{'pattern-style' : address.name.pattern}" v-model="address.name.val" placeholder="请输入收件人名字" /></div>
                </div>
                <div class="list">
                    <div class="name"><span style="color: #0386B6;padding-right:3px">*</span><span style="letter-spacing:4.5px;">手机号</span>：</div>
                    <div class="value"><input ref="phone" type="text" maxlength="11" :class="{'pattern-style' : address.phone.pattern}" v-model="address.phone.val" placeholder="请输入收件人手机号" /></div>
                </div>
                <div class="list">
                     <div class="name"><span style="color: #0386B6;padding-right:3px">*</span>详细地址：</div>
                    <div class="value"><textarea ref="location" type="text" :class="{'pattern-style' : address.location.pattern}" v-model="address.location.val" placeholder="请输入收件人地址" /></div>
                </div>
            </div>

            <div class="row2">
                <div class="image">
                    <van-image width="50" height="50" :src="shopInfo.thumb_img" />
                </div>
                <div class="textContext">
                    <div class="text van-ellipsis">{{shopInfo.goods_name}}</div>
                    <div class="desc">
                        {{utils.filterPrice(shopInfo.price)}} <span>竞猜币</span>
                    </div>
                </div>
                <div class="num">×1</div>
            </div>
            <div class="row3">
                <div class="left">商品总付</div>
                <div class="right"><span style="font-size: 15px;color:#1de7e7;font-family:'DIN'">{{utils.filterPrice(shopInfo.price)}}</span> 竞猜币</div>
            </div>
            <!-- <div class="row4">
                <div class="list">
                    <div class="left">订单号</div>
                    <div class="right">25a5sdds26646 
                        <span
                          v-clipboard:copy="25135345345345"
                          v-clipboard:success="onCopy"
                          v-clipboard:error="onError"
                          style="color:#FFFFFF"
                        ><van-image width="12" :src="require('../assets/images/Icon_copy_xiao.png')" /></span></div>
                </div>
                <div class="list">
                    <div class="left">创建时间</div>
                    <div class="right">2020-05-27 18:20:19</div>
                </div>
                <div class="list">
                    <div class="left">支付时间</div>
                    <div class="right">2020-05-27 18:20:19</div>
                </div>
            </div> -->
        </div>
         <div class="bottom">
            <van-goods-action>
                <div class="price"><span style="font-size: 26px">{{utils.filterPrice(shopInfo.price)}}</span> 竞猜币</div>
                <van-goods-action-button
                    text="立即兑换"
                    color="#1bafff"
                    @click="onOrder"
                />
            </van-goods-action>
        </div>
        <van-overlay :show="loading" z-index="1000">
            <div class="wrapper">
                <van-loading class="spinner" type="spinner" />
            </div>
        </van-overlay>
    </div>
</template>

<script>
import Vue from 'vue';
// Dialog
import { Toast, Notify, CountDown, Dialog  } from "vant";
import ComponentHeader from './../components/ComponentHeader';
import axios from 'axios';
Vue.use(Notify);
Vue.use(CountDown);
export default {
    components: {
        ComponentHeader
    },
    data() {
        return {
            shopInfo: {},
            address: {
                name: {
                    val: '',
                    pattern: false
                },
                phone: {
                    val: '',
                    pattern: false
                },
                location: {
                    val: '',
                    pattern: false
                }
            },
            time: 60 * 30 * 1000,
            loading: true,
            account:'',
            show:true,
            phoneError:false,
        };
    },
    mounted() {
        let { id, account } = this.$route.query;
        this.account = account;
        axios.post(this.config.HOST + "api/order/confirm", {
            goods_id: id,
            account: this.account,
        })
        .then(response => {
            this.loading = false;
            let result = response.data;
            if (result.code == 0) {
                let { data } = result;
                if (JSON.stringify(data) != "{}") {
                    this.shopInfo = data;
                } else {
                    this.shopInfo = null;
                }
            } else {
                this.$router.go(-1);
            }
        });
    },
    methods: {
        onCopy() {
            Toast("复制成功!");
        },
        onError() {
            Toast("复制失败!");
        },
        // onTimeData(timeDate) {
            // console.log(1234, timeDate);
        // },
        backOrder() {
            if (this.shopInfo.goods_type == 2) {
                if (!this.address.name.val || !this.address.phone.val || !(/^1[3456789]\d{9}$/.test(this.address.phone.val)) || !this.address.location.val) { 
                    Dialog.confirm({
                        message: '你还未输入地址，是否继续填写地址?',
                        confirmButtonText: '确认',
                        confirmButtonColor: '#bacef1',
                        cancelButtonText: '取消',
                        cancelButtonColor: '#526686',
                        className: "dialog"
                    })
                    .then(() => {
                        // on confirm
                        if (!this.address.name.val) {
                            this.$refs.name.focus();
                            this.address.name.pattern = true;
                        }
                        if (!this.address.phone.val || !(/^1[3456789]\d{9}$/.test(this.address.phone.val))) {
                            this.phoneError = true;
                            setTimeout(()=>{
                                this.phoneError  =false;
                            },1000)
                            this.$refs.phone.focus();
                            this.address.phone.pattern = true;
                        }
                        if (!this.address.location.val) {
                            this.$refs.location.focus();
                            this.address.location.pattern = true;
                        }
                    })
                    .catch(() => {
                        this.$router.go(-1);
                    });
                } else {
                    Dialog.confirm({
                        title: '当前还未支付，再考虑考虑？',
                        confirmButtonText: '确认',
                        confirmButtonColor: '#bacef1',
                        cancelButtonText: '取消',
                        cancelButtonColor: '#526686',
                        className: "dialog"
                    })
                    .catch(() => {
                        let { id } = this.shopInfo;
                        axios.post(this.config.HOST + "api/order/create", {
                            goods_id: id,
                            account: this.account,
                            receipt_name: this.shopInfo.goods_type == 2 ? this.address.name.val : undefined,
                            receipt_mobile: this.shopInfo.goods_type == 2 ? this.address.phone.val : undefined,
                            receipt_address: this.shopInfo.goods_type == 2 ? this.address.location.val : undefined,
                        })
                        .then(response => {
                            let result = response.data;
                            if (result.code == 0) {
                                this.$router.replace({
                                    path: 'exchange',
                                    query: {
                                        active: 0
                                    }
                                });
                            } else {
                                Toast({
                                    message: '兑换失败',
                                    icon: 'cross',
                                    onOpened: () => {
                                        this.$router.go(-1);
                                    }
                                });
                            }
                        });
                    })
                }
            } else {
                Dialog.confirm({
                    message: '当前还未支付，再考虑考虑？',
                    confirmButtonText: '确认',
                    confirmButtonColor: '#bacef1',
                    cancelButtonText: '取消',
                    cancelButtonColor: '#526686',
                    className: "dialog"
                })
                .catch(() => {
                    let { id } = this.shopInfo;
                    axios.post(this.config.HOST + "api/order/create", {
                        goods_id: id,
                        account: this.account,
                        receipt_name: this.shopInfo.goods_type == 2 ? this.address.name.val : undefined,
                        receipt_mobile: this.shopInfo.goods_type == 2 ? this.address.phone.val : undefined,
                        receipt_address: this.shopInfo.goods_type == 2 ? this.address.location.val : undefined,
                    })
                    .then(response => {
                        let result = response.data;
                        if (result.code == 0) {
                            // 跳转订单
                            this.$router.replace({
                                path: 'exchange',
                                query: {
                                    active: 0
                                }
                            });
                        } else {
                            Toast({
                                message: '兑换失败',
                                icon: 'cross',
                                onOpened: () => {
                                    this.$router.go(-1);
                                }
                            });
                        }
                    });
                });
            }
        },
        onOrder() {
            if (this.shopInfo.goods_type == 2) {
                if (!this.address.name.val) {
                    this.address.name.pattern = true;
                    this.$refs.name.focus();
                    return;
                }
                if (!this.address.phone.val || !(/^1[3456789]\d{9}$/.test(this.address.phone.val))) {
                    this.phoneError = true;
                    setTimeout(()=>{
                        this.phoneError  =false;
                    },1000)
                    this.$refs.phone.focus();
                    this.address.phone.pattern = true;
                    return;
                }
                if (!this.address.location.val) {
                    this.$refs.location.focus();
                    this.address.location.pattern = true;
                    return;
                }
            }
            
            let { id } = this.shopInfo;
            axios.post(this.config.HOST + "api/order/create", {
                goods_id: id,
                account: this.account,
                receipt_name: this.shopInfo.goods_type == 2 ? this.address.name.val : undefined,
                receipt_mobile: this.shopInfo.goods_type == 2 ? this.address.phone.val : undefined,
                receipt_address: this.shopInfo.goods_type == 2 ? this.address.location.val : undefined,
            })
            .then(response => {
                let result = response.data;
                if (result.code == 0) {
                    if (result.code == 0) {
                        axios.post(this.config.HOST + "api/order/pay", {
                            order_sn: result.order_sn
                        })
                        .then(response => {
                            let result = response.data;
                            if (result.code == 0) {
                                if (result.code == 0) {
                                    Toast({
                                        message: '已兑换成功',
                                        icon: require('../assets/images/popwindow.png'),
                                        onOpened: () => {
                                            this.$router.replace({ path: 'exchange' });
                                        }
                                    });
                                } else {
                                    Toast({
                                        message: '兑换失败',
                                        icon: 'cross',
                                        onOpened: () => {
                                            this.$router.replace({ path: 'exchange' });
                                        }
                                    });
                                }
                            }
                        });
                    } else { 
                        Toast({
                            message: '兑换失败',
                            icon: 'cross',
                            onOpened: () => {
                                this.$router.replace({ path: 'exchange' });
                            }
                        });
                    }
                }
            });
        },
    }
};
</script>

<style lang="less" scoped>
    .page-payment {
        .wrapper{
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
        // 导航
        .nav-row {
            .nav {
                top: 46px;
                color: #ffffff;
                background-color: #090c15;
                .title {
                    color: #BACEF1 !important;
                }
            }
        }
        // 内容部分
        .content{
            padding: 0px 0 0 0;
            .row1 {
                color: #019DD4;
                text-align: center;
                padding: 15px 0;
                border-bottom: 1px solid #262f40;
                font-size: 14px;
            }
            .phoneError{
                display: flex;
                background:red;
                height: 40px;
                justify-content: center;
                align-items: center;
                color:#fff;
                font-family: "DIN";
                img{
                    width:36px;
                }
            }
            /* 账号 */
            .account {
                border-bottom: 1px solid #262f40;
                padding: 8px 15px;
                font-size: 14px;
                color: #fff;
                font-weight: bold;
                .editbox{
                    display: flex;
                    align-items: center;
                    .text{
                        margin-left:8px;
                        color:#becef1;
                        display: inline-block;
                        width:76%;
                        height: 30px;
                        background:#1d2538;
                        display: flex;
                        align-items: center;
                        padding:0 15px;
                        font-size: 15px;
                        border-radius: 6px;
                        font-weight: normal;
                        span{
                            flex:1;
                        }
                        img{
                            width: 12px;
                        }
                        input{
                            border:none;
                            outline:none;
                            background:none;
                            padding:0px;
                        }
                    }
                }
                
            }
            /* 地址 */
            .address{
                display: flex;
                flex-direction: column;
                padding: 7.5px 15px;
                font-size: 16px;
                border-bottom: 1px solid #262f40;
                .list{
                    display: flex;
                    padding: 7.5px 0;
                    .name {
                        color: #bacef1;
                    }
                    .value {
                        input {
                            border: 0;
                            background: transparent;
                            color: #ffffff;
                            padding: 5px 0px 3px 8px;
                            font-size: 14px
                        }
                        input::-webkit-input-placeholder {
                            color: #4f6282;
                            font-size: 14px
                        }
                        input.pattern-style::-webkit-input-placeholder {
                            color: red;
                        }
                        textarea{
                            background:none;
                            outline: none;
                            resize: none;
                            border:none;
                            width:230px;
                            color:#fff;
                            font-size: 13px;
                            padding: 5px 0px 3px 8px;
                        }
                        textarea::-webkit-input-placeholder {
                            color: #4f6282;
                            font-size: 14px
                        }
                        textarea.pattern-style::-webkit-input-placeholder {
                            color: red;
                        }
                    }
                }
            }

            // 商品图片
            .row2 {
                display: flex;
                align-items: center;
                overflow: hidden;
                box-sizing: border-box;
                padding: 15px;
                border-bottom: 1px solid #262f40;
                .image {
                    background: none;
                    img {
                        border-radius: 50%;
                    }
                }
                .textContext {
                    max-width: 90%;
                    overflow: hidden;
                    flex: 1;
                    .text {
                        white-space: nowrap;
                        text-overflow: ellipsis;
                        overflow: hidden;
                        font-size: 16px;
                        color: #ffffff;
                        font-weight: bold;
                        width: 100%;
                    }
                    .desc {
                        font-size: 14px;
                        color: #bacef1;
                        font-family: 'DIN';
                        span{
                            font-size: 13px;
                            font-family: normal;
                        }
                    }
                    .text,
                    .desc {
                        padding: 0px 10px 10px 15px;
                    }
                }
                .num{
                    width: 20%;
                    color: #bacef1;
                    text-align: right;
                    font-size: 13px;
                    font-weight: bold;
                }
            }
        }

        .row3 {
            display: flex;
            color: #bacef1;
            padding: 15px 15px;
            .left {
                flex: 1;
                font-size: 14px;
                color: #becef1;
            }
            .right {
                font-size: 12px;
            }
        }
        
        .row4 {
            color: #35435A;
            padding: 3px 12px 12px;
            font-size: 14px;
            .list{
                display: flex;
                padding: 3px 0;
                .left{
                    flex: 1;
                }
            }
        }

        /* 底部 */
        .bottom {
            .price {
                font-size: 13px;
                color: #bacef1;
                padding:0 0 0 12px;
                width: 60%;
            }
            .van-goods-action {
                height: 44px;
                background-color: #363c53;
            }
            .van-goods-action-icon {
                background-color: #363c53;
                color: #B3C6E8;
            }
            .van-goods-action-button--last {
                border-radius: 0;
                height: 100%;
                margin: 0 0 0 5px;
                font-size: 15px;
                font-weight: bold;
            }
        }
    }
</style>

