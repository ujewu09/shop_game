<template>
  <div class="page-index">
    <component-header :back="false">
        <!-- <template #left>
            <img @click="$router.go(-1)" src="./../assets/images/icon_back.png" />
        </template> -->
        <template #title>
            商城
        </template>
        <template #right>
                <img @click="$router.push({path: '/exchange'})" src="./../assets/images/xuanxuan-image2.png" />
        </template>
    </component-header>
    <div class="tab">
        <van-tabs 
            class="tabs" 
            v-model="active" 
            swipeable 
            title-active-color="#FFFFFF" 
            title-inactive-color="#95A5C4" 
            :sticky="true" 
            color="#28FFD4" 
            :border="false" 
            background="#0C1220" 
            line-width="28"
            @change="onChange"
            offset-top="46"
            >
            <van-tab v-for="itemp in list" :key="itemp.id" :name="itemp.id" :title="itemp.name">
                <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
                    <van-list
                        v-model="upLoading"
                        :finished="finished"
                        finished-text="已经到底了"
                        @load="onLoad">
                        <div class="tabListContent" v-show="itemp.id == active">
                            <van-row gutter="8" ref="rowList" >
                                <van-col span="12" v-for="item in listContent" :key="item.id" v-show="itemp.id == item._goodsType"  @click="onDetails(item)">
                                    <div class="block">
<!--                                        <div class="leftTab">-->
<!--                                            {{item.goods_type == 1 && "虚拟" || -->
<!--                                            item.goods_type == 2 && "实物"}}-->
<!--                                        </div>-->
                                        <div class="images">
                                            <van-image :src="item.thumb_img">
                                                <template v-slot:loading>
                                                    <van-loading type="spinner" size="20" />
                                                </template>
                                                <template v-slot:error>
                                                    <img style="max-width: 100%" src="../assets/images/error-image.png" />
                                                </template>
                                            </van-image>
                                        </div>
                                        <p class="van-ellipsis">{{item.goods_name}}</p>
                                        <p>等级≥ VIP{{item.user_level}}<span>
                                            ({{item.type == 1 && "已达标" || item.type == 0 && "未达标"}})</span></p>
                                        <div>
                                            <van-button plain hairline @click="onDetails(item)"
                                                :disabled="item.type == 0"
                                                class="btn-auto">
                                                {{item.price}}竞猜币</van-button>
                                        </div>
                                    </div>
                                </van-col>
                                <!-- 解决框架Bug  数量为奇数的时候gutter=8出现不对齐 -->
                                <van-col span="12"></van-col>
                            </van-row>
                        </div>
                    </van-list>

                </van-pull-refresh>
                
            </van-tab>
        </van-tabs>
    </div>
    <div class="bottom">
        <div class="left" span="12">
            <p>竞猜币余额：<span>{{utils.filterPrice(config.PRICE)}}</span></p>
        </div>
        <div class="right" span="12">
            <p>今日还可兑换<span> {{config.COUNT}} </span>次</p>
        </div>
    </div>
<!--    <div :class="{'shopping': true, 'shoppingShow': !shoppingShow}">-->
<!--        <van-image @click="$router.push({path: 'exchange'})" :src="require('../assets/images/Button_exchange.png')" />-->
<!--    </div>-->
  </div>
</template>

<script>
import Vue from 'vue';
import axios from "axios";
import ComponentHeader from './../components/ComponentHeader';
import { PullRefresh, Loading } from 'vant';
Vue.use(PullRefresh);
Vue.use(Loading);
export default {
    components: {
        ComponentHeader
    },
    data() {
        return {
            active: 0,
            list: null,
            listContent: [],
            downLoading: false,
            upLoading: false,
            finished: false,
            currentTypeID: 0,
            pages: {
                page: {},
                limit: 12
            },
            // shoppingShow: true
        };
    },
    mounted () {
        // 商品分类
        axios
        .post(this.config.HOST + "api/category/list",{})
        .then(response => {
            let result = response.data;
            if (result.code == 0) {
                let { data } = result;
                if (data.length > 0) {
                    this.list = data;
                    this.currentTypeID = data[0].id;
                } else {
                    this.list = null;
                }
            }
        })
/*
        let t1 = 0;
        let t2 = 0;
        let timer = null; // 定时器
        let isScrollEnd = () => {
            t2 = document.documentElement.scrollTop || document.body.scrollTop;
            if(t2 == t1){
                this.shoppingShow = true;
            }
        }
        //实现上拉下拉滚动条的时候隐藏悬浮的发帖按钮
        window.addEventListener('scroll', ()=>{
            clearTimeout(timer);
            timer = setTimeout(isScrollEnd, 500);
            t1 = document.documentElement.scrollTop || document.body.scrollTop;
            this.shoppingShow = false;
        }, false);*/
    },
  methods: {
    onDetails(data) {
        if (data.type == 0) {
            return;
        }
        this.$router.push({ path: 'productDetails', query: { id: data.id }})
    },
    onChange(ID) {
        this.listContent = [];
        this.currentTypeID = ID;
        this.pages.page['page' + this.currentTypeID] = 1;
        this.finished = false;
        this.getShopList({
            page:  this.pages.page['page' + this.currentTypeID],
            limit: this.pages.limit,
            category_id: this.currentTypeID
        });
        this.minHeight();
    },
    onRefresh(){
        // 下拉
        this.pages.page['page' + this.currentTypeID] = 1;
        this.finished = false;
        this.getShopList({
            page:  this.pages.page['page'+ this.currentTypeID],
            limit: this.pages.limit,
            category_id: this.currentTypeID
        }, () => {
            this.listContent = [];
            this.downLoading = false;
        });
    },
    onLoad() {
        // 上拉
        // 到底部执行加载
        if (this.pages.page['page' + this.currentTypeID]) {
            this.pages.page['page' + this.currentTypeID]+=1;
        } else {
            this.pages.page['page' + this.currentTypeID] = 1;
        }
        this.getShopList({
            page:  this.pages.page['page'+ this.currentTypeID],
            limit: this.pages.limit,
            category_id: this.currentTypeID
        });
        this.minHeight();
    },
    minHeight() {
       // 设置列表内容最小高度
        let clearTabList = setInterval(() => {
            let con = this.$refs.rowList
            if (con.length > 0 && con[0].$el) {
                con.map(item => {
                     item.$el.style.minHeight = (window.screen.height - 205) + "px";
                })
                clearInterval(clearTabList);
            }
      }, 100);
    },
    getShopList(obj, callback){
        axios.post(this.config.HOST + "api/goods/list",obj).then(response => {
            let result = response.data;
            if (callback) {
                callback(result);
            }
            if (result.code == 0) {
                let { data } = result;
                if (data.length > 0) {
                    this.upLoading = false;
                    let modify = data;
                    // 赋值商品类型ID
                    for(let i = 0;i < modify.length; i++){
                        modify[i]._goodsType = obj.category_id;
                    }
                    this.listContent = this.listContent.concat(modify);
                } else {
                    this.upLoading = true;
                    this.finished = true;
                }
            } else {
                this.upLoading = true;
                this.finished = true;
            }

        })
    },
  }
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import url('../assets/style/color.less');
    .page-index{
        .shopping {
            opacity: 1;
            transition: all 0.5s;
        }
        .shoppingShow {
            opacity: 0;
        }
        // tab 页
        .tab {
            position: relative;
            text-align: left;
            background-color: #0C1220;

            ::v-deep {
                .van-tabs__wrap {
                    overflow: hidden;
                    overflow-x: auto;
                    border-bottom: 1px solid #192032;
                    &::-webkit-scrollbar {
                        display: none;
                    }
                }
                .van-tab{
                    position: relative;
                    flex: auto !important;
                    max-width: 100px;
                    min-width: 81px;
                    &::after {
                        position: absolute;
                        top: 50%;
                        left: 0;
                        content: '';
                        height: 20px;
                        width: 1px;
                        background: #333c4e;
                        transform: translateY(-50%);
                    }
                }
                .van-tab:first-child{
                    ::after {
                        width: 0px;
                    }
                }
            }


            .tabListContent {
                padding: 2px 15px 0 15px;
                margin-top: 25px;
            }
            .van-sticky--fixed{
                top:46px !important;
            }
            .block{
                margin: 8px 0 0 0;
                padding: 10px 0 10px 0;
                text-align: center;
                position: relative;
                color:#ffffff;
                border-radius: 5px;
                background-color: #1D2538;

                &::v-deep .van-image__error {
                    background: none;
                }

                .van-ellipsis{
                    margin: 0;
                    padding: 15px 5px 5px 5px;
                    font-size: 15px;
                    color: #ffffff;
                    // font-weight: bold;
                }

                p{
                    padding: 0 0 10px 0;
                    margin: 0;
                    font-size: 12px;
                    color: #bacef1;
                    span{
                        color: #4f6282;
                    }
                }

                .leftTab{
                    position: absolute;
                    top: 10px;
                    font-size: 10px;
                    padding: 3px 10px 3px 5px;
                    font-weight: bold;
                    line-height: 1.7em;
                    border-top-right-radius: 12px;
                    border-bottom-right-radius: 12px;
                    background-color: #1C5D93;
                }

                .btn-auto{
                    height: 26px;
                    width: 120px;
                    padding: 0 8px;
                    border: transparent;
                    background-image: linear-gradient(-90deg, #00a4f6, #00cbdc);
                    color: #ffffff;
                    font-size: 12px;
                    font-weight: bold;
                    border-radius: 3px;

                    &[disabled="disabled"]{
                        background-image:none;
                        background-color: transparent;
                        border:1px solid #2f3950;
                        color: #526583;
                    }
                    
                    .van-button__text{
                        white-space: nowrap;
                        text-overflow: ellipsis;
                        overflow: hidden;
                    }
                }
                .images {
                    position: relative;
                    width: 50px;
                    height: 50px;
                    margin: 0 auto;
                    overflow: hidden;
                    top: 5px;
                    &::v-deep {
                        .van-image{
                            height: 50px;
                            width:50px;
                            .van-image__img {
                                width: 100%;
                                height: 100%;
                                max-height: 100% !important;
                            }
                        }
                    }
                }
            }

            // 强制修改组件内部样式
            ::v-deep 
            {
                [role="tab"] {
                    font-size: 13px;
                    font-weight: bold;
                }
                [aria-selected="true"] {
                    font-weight: bold;
                    font-size: 15px;
                }
                .van-list__finished-text, .van-list__loading *, .van-pull-refresh__head *{
                    color: #526583;
                    font-size: 12px;
                }
                .van-list{
                    padding-bottom: 40px;
                }
            }
        }

        // 底部
        .bottom {
            position: fixed;
            top:91px;
            left: 0;
            height: 25px;
            line-height: 25px;
            width: 100%;
            background:#0C1220;
            color: #A7B9D9;
            font-size: 12px;
            padding: 0 15px;
            box-sizing: border-box;
            display: flex;
            .left {
                color: #BACEF1;
                font-size: 12px;
                flex: 1;
                // font-weight: bold;
                span{
                    color: #1bafff;
                    /*font-size: 16px;*/
                }
            }
            .right {
                text-align: right;
                color: #BACEF1;
                font-size: 12px;
                span{
                    color: #1bafff;
                    /*font-size: 16px;*/
                }
            }

            p{
                margin: 4px 0px 0px 0px;
            }
        }
        /* 购物车 */
        .shopping {
            position: fixed;
            right: 20px;
            bottom: 60px;
            width: 60px;
            height: 60px;
            padding: 5px;
            box-sizing: border-box;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
        }
    }
</style>
