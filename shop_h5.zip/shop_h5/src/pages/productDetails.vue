<template>
  <div class="page-product-details">
    <component-header>
      <template #left>
        <img @click="$router.go(-1)" src="./../assets/images/icon_back.png" />
      </template>
      <template #title>
        详情
      </template>
      <template #right>
          <img @click="$router.push({path: '/exchange'})" src="./../assets/images/xuanxuan-image2.png" />
      </template>
    </component-header>

    <div class="swipe">
      <van-swipe @change="onChange" height="550px">
        <van-swipe-item v-for="(itemImg) in details.swipeItem" :key="itemImg">
          <van-image :src="itemImg" />
        </van-swipe-item>
        <template #indicator>
          <div class="custom-indicator">{{ current + 1 }}/ {{sumLength}}</div>
        </template>
      </van-swipe>
    </div>
    <div class="swipe-bottom">
      <div class="row1">
        <div class="left">
          <span style="font-size: 30px;color: #1de7e7">{{details.price}}</span>&nbsp;
          <span style="font-weight: bold;color:bacef1;">竞猜币</span>
        </div>
        <div class="right">竞猜币余额: {{utils.filterPrice(details.gold)}}</div>
      </div>
      <div class="row2">
        <div class="left">
          <van-tag round type="danger" style="position: relative;top: -1px;font-weight: 300;" color="#E25F2B">
            {{details.goodsType == 1 && "虚拟" ||
            details.goodsType == 2 && "实物"}}
          </van-tag>
          <span style="padding-left:5px;font-weight: 500;">{{details.goodsName}}</span>
        </div>
        <div class="right">库存: {{details.stock}}</div>
      </div>
    </div>
    <div class="account" v-if="details.isAccount == 1">
        <div class="tips">*</div>
        <div class="text">账号</div>
        <div class="input">
            <input type="text" ref="account" v-model="accountVal" :class="{'require-style': requires}" :placeholder="requireVal" />
        </div>
    </div>
    <div class="details">
      <h4 style="font-weight: 100;">商品详情</h4>
      <div>
          <div style="text-align:center" v-for="(itemImg, index) in details.goodsDetail" :key="index">
            <img :src="itemImg" />
          </div>
      </div>
    </div>
    <div class="bottom">
      <van-goods-action>
        <van-goods-action-icon color="#FFFFFF" @click="$router.push({path: 'exchange'})">
            <!-- <van-image style="display: block;margin: 0 auto;padding-bottom:5px" width="16" :src="require('../assets/images/exchange.png')" /> -->
            我的兑换
        </van-goods-action-icon>

        <van-goods-action-button
          text="立即兑换"
          color="#1bafff"
          @click="onExchange"
        />
      </van-goods-action>
    </div>
    <van-overlay :show="loading" z-index="1000">
      <div class="wrapper">
        <van-loading class="spinner" type="spinner" />
      </div>
    </van-overlay>
  </div>
</template>

<script>
import Vue from "vue";
import axios from "axios";
import ComponentHeader from './../components/ComponentHeader';
import {
  Swipe,
  SwipeItem,
  Tag,
  GoodsAction,
  GoodsActionIcon,
  GoodsActionButton,
  Dialog,
  overlay,
  loading
} from "vant";
Vue.use(Swipe);
Vue.use(SwipeItem);
Vue.use(Tag);
Vue.use(GoodsAction);
Vue.use(GoodsActionButton);
Vue.use(GoodsActionIcon);
Vue.use(overlay);
Vue.use(loading);
export default {
  components: {
    ComponentHeader
  },
  data() {
    return {
      current: 0,
      sumLength: 0,
      details: {
        swipeItem: null,
        goodsDetail: null,
        goodsName: "",
        goodsType: 0,
        id: 0,
        isAccount: 0,
        price: 0,
        status: 0,
        userLevel: 0
      },
      accountVal: '',
      requireVal: '请输入账号，如QQ号、爱奇艺等',
      requires: false,
      loading: true
    };
  },
  mounted() {
    axios
      .post(this.config.HOST + "api/goods/detail", {
        id: this.$route.query.id
      })
      .then(response => {
        let result = response.data;
        this.loading = false;
        if (result.code == 0) {
          let { data } = result;
          if (JSON.stringify(data) != "{}") {
            this.details.swipeItem = data.goods_img;
            this.sumLength = this.details.swipeItem.length;
            this.details.goodsDetail = data.goods_detail;
            this.details.goodsName = data.goods_name;
            this.details.goodsType = data.goods_type;
            this.details.id = data.id;
            this.details.isAccount = data.is_account;
            this.details.price = data.price;
            this.details.status = data.status;
            this.details.userLevel = data.user_Level;
            this.details.gold = data.gold;
            this.details.stock = data.stock;
          } else {
            this.details.swipeItem = null;
          }
        } else {
            this.$router.go(-1);
        }
      });
  },
  methods: {
    onChange(index) {
        this.current = index;
    },
    onExchange() {
        if (this.details.isAccount == 1) {
            if (!this.accountVal) {
                this.requireVal = "请输入账号";
                this.requires = true;
                return;
            } else {
                this.requireVal = "请输入账号，如QQ号、爱奇艺等";
                this.requires = true;
            }

            Dialog.confirm({
                title: '账号确认',
                message: '请再次核对账号是否填写正确！如填写错误，请自行承担后果！',
                confirmButtonText: '确认',
                confirmButtonColor: '#bacef1',
                cancelButtonText: '去修改',
                cancelButtonColor: '#526686',
                className: "dialog"
            })
            .then(() => {
                this.$router.push({ 
                    path: "payment", 
                    query: { 
                        id:  this.details.id,
                        account:  this.details.isAccount == 1 ? this.accountVal : undefined
                    } 
                });
            })
            .catch(() => {
                this.$refs.account.focus();
            });
        } else {
            this.$router.push({ 
                path: "payment", 
                query: { 
                    id:  this.details.id,
                    account:  this.details.isAccount == 1 ? this.accountVal : undefined
                } 
            });
        }
    }
  }
};
</script>
<style scoped>
.page-product-details {
  text-align: left;
}
.page-product-details .wrapper{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
}
.page-product-details .block {
  width: 120px;
  height: 120px;
  background-color: #fff;
}
 /* .page-product-details .swipe {
  height: 300px; 
} */
.page-product-details .headerTop {
  padding: 15px;
  box-sizing: border-box;
  position: fixed;
  top: 46px;
  left: 0;
  width: 100%;
  color: red;
  z-index: 100;
}
.page-product-details .headerTop .nav {
  display: flex;
}
.page-product-details .headerTop .nav .left {
  text-align: left;
  flex: 1;
}
.page-product-details .headerTop .nav .right {
  text-align: right;
  flex: 1;
}
.page-product-details .custom-indicator {
  position: absolute;
  right: 10px;
  bottom: 15px;
  padding: 5px 8px;
  font-size: 12px;
  background: rgba(0, 0, 0, 0.5);
  border-top-left-radius: 14px;
  border-top-right-radius: 12px;
  border-bottom-left-radius: 12px;
  border-bottom-right-radius: 12px;
  color: #bacef1;
}
/* 轮播底部标题 */
.page-product-details {
    background-color: #0C1220;
}
.page-product-details .swipe-bottom {
  padding: 15px 15px 20px 15px;
  border-bottom: 2px solid #10182a;
  /* background: #0C1220; */
}
.page-product-details .swipe-bottom .row1 {
  display: flex;
  padding: 0 0 5px 0;
}
.page-product-details .swipe-bottom .row1 .left {
  flex: 1;
  font-size: 15px;
  color: #bacef1;
}
.page-product-details .swipe-bottom .row1 .right {
  font-size: 12px;
  color: #4f6282;
  padding-top: 11px
}
.page-product-details .swipe-bottom .row2 {
  display: flex;
}
.page-product-details .swipe-bottom .row2 .left {
  flex: 1;
  font-size: 16px;
  font-weight: bold;
  color: #ffffff;
}
.page-product-details .swipe-bottom .row2 .right {
  font-size: 12px;
  color: #526583;
  padding-top: 2px;
}
/* 详情 */
.page-product-details .details {
  padding: 0 0 50px 0;
}
.page-product-details .details h4 {
  padding: 0 0px 0 12px;
  margin: 15px 0 15px 0;
  color: #bacef1;
}
.page-product-details .details img {
  vertical-align: middle;
  margin: 15px;
  padding: 0;
  margin: 0;
  max-width: 100%;
}
/* 账号 */
.page-product-details .account {
  display: flex;
  padding: 15px;
  line-height: 30px;
  border-bottom: 2px solid #10182a;
}
.page-product-details input::-webkit-input-placeholder {
  color: #4f6282;
  font-size: 14px;
  text-align: center;
}
.page-product-details input.require-style::-webkit-input-placeholder{
    color: red;
}
.page-product-details .account .tips {
  padding: 5px 8px 0 0px;
  font-size: 16px;
  color: #00b0ed;
}
.page-product-details .account .text {
  color: #ffffff;
  padding: 0 10px 0 0;
  font-size: 14px;
}
.page-product-details .account .input {
  flex: 1;
  box-sizing: border-box;
}
.page-product-details .account .input input {
  width: 100%;
  height: 30px;
  line-height: 30px;
  margin: 0;
  padding: 0px 16px;
  background-color: #1d2538;
  border: 1px solid #1d2538;
  box-sizing: border-box;
  color: #ffffff;
  font-size: 12px;
  border-radius: 4px;
}

/* 底部 */
.page-product-details .bottom .van-goods-action {
  background-color: #1d2538;
  height: 44px;
}
.page-product-details .bottom .van-goods-action-icon {
  width: 50%;
  background-color: #363c53;
  color: #bacef1;
  font-size: 15px;
  font-weight: bold;
}
.page-product-details .bottom .van-goods-action-button--last {
  border-radius: 0;
  height: 100%;
  width: 50%;
  margin: 0 0 0 0;
  font-size: 15px;
  font-weight: bold;
}
</style>
