<template>
    <div class="page-exchange-rules">
        <component-header>
            <template #left>
                <img @click="$router.go(-1)" src="./../assets/images/icon_back.png" />
            </template>
            <template #title>
                兑换规则
            </template>
        </component-header>
<!--        <div class="nav-row">-->
<!--            <van-nav-bar left-arrow fixed z-index="10" class="nav" :border="false">-->
<!--                <template #title>-->
<!--                    <span class="title">兑换规则</span>-->
<!--                </template>-->
<!--                <template #left>-->
<!--                    <span-->
<!--                        style="-->
<!--                        margin-left:-1px;-->
<!--                        margin-top: -3px;-->
<!--                        font-size:14px;-->
<!--                        text-align: center;-->
<!--                        display:inline-block;-->
<!--                        width:23px;-->
<!--                        height:23px;-->
<!--                        line-height:26px;-->
<!--                        border-radius:50%-->
<!--                        color: #B8CCEF;-->
<!--                        background-color: #21263B;"-->
<!--                        @click="$router.go(-1)"-->
<!--                    ><van-icon name="arrow-left" color="#fff" /></span>-->
<!--                </template>-->
<!--                <template #right>-->
<!--                    &lt;!&ndash; <van-image width="18" :src="require('../assets/images/service.png')" /> &ndash;&gt;-->
<!--                </template>-->
<!--            </van-nav-bar>-->
<!--        </div>-->
        <div class="text-content">
            <div class="row">
                <h3 class="title">非实物商品(虚拟商品)兑换</h3>
                <div class="content">
                    <ul>
                        <li>1、可以用多个竞猜币兑换为非实物商品。</li>
                        <li>2、兑换生效后，如有使用期限的，请在商品有效期内使用，商品有效期以兑换当时最新活动公告或官方信息为准，超过有效期未使用，商品将自动失效；无使用期限的无需理会。</li>
                        <li>3、确认兑换支付竞猜币后，除系统不能自动发放的商品，开心电竞官方客服会在3个工作日内联系您，并发放商品。如遇节假日，顺延并给您兑换相关商品。</li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <h3 class="title">实物商品兑换</h3>
                <div class="content">
                    <ul>
                        <li>1、商品数量有限，先兑先得，兑完即止。商品一经兑换成功后，会扣除相应竞猜币，概不退换。</li>
                        <li>2、提交收货信息后，工作人员将在信息提交后的一周内派发商品；若需修改个人收货信息需联系在线客服，已派发的商品不可修改。</li>
                        <li>3、兑换成功后，您可以到“我的兑换”中查询已兑换商品。</li>
                        <li>4、竞猜币兑换的礼品以开心电竞平台上的资料为准，如遇不可抗力因素，竞猜币保留更换其它等值奖项的权利。</li>
                        <li>5、您的收货信息是保证物品顺利邮寄的关键，请一定要谨慎填写，包括您的姓名、电话、邮编、邮寄地址（仅限中国大陆，新疆、西藏等偏远地区由于快递原因无法送达，建议兑换虚拟商品）。</li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <h3 class="title">注意事项</h3>
                <div class="content">
                    <ul>
                        <li>1、在商城兑换，只能使用竞猜币，若竞猜币不足，请到钱包页面，由平台币转换至竞猜币后，再兑换商品。</li>
                        <li>2、开心电竞官方不会主动向您索要任何银行账户密码，身份信息请勿泄露，陌生电话请勿轻信，涉及到钱财需小心。</li>
                        <li>3、对于存在作弊、不良交易、不良注册、发送垃圾消息、欺诈等不良行为的账号及其相关联的账号，以及已被冻结的账号及其相关联的账号，开心电竞官方有权对其做扣除竞猜币处理。</li>
                        <li>4、以上所有规则最终解释权归开心电竞官方所有。</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
</template>

<script>
import Vue from 'vue';
// import axios from 'axios';
import { Image as VanImage} from "vant";
import ComponentHeader from './../components/ComponentHeader';
Vue.use(VanImage);
export default {
    components: {
        ComponentHeader
    },
    data() {
        return {
            // current: 0
        };
    },
    mounted(){
        /*
        axios.post(this.config.HOST + "api/exchange/rules", {

        })
        .then(response => {
            // let {code, data} = response;
        });*/
    },
    methods: {
        // onClickLeft() {
        //     Toast("返回");
        // }
    }
};
</script>
<style scoped>
/*.page-exchange-rules .nav-row .nav {*/
/*    top: 46px;*/
/*    color: #ffffff;*/
/*    background-color: #090c15;*/
/*}*/
.page-exchange-rules .nav-row .nav .title {
    color: #BACEF1 !important;
}
/* 列表内容 */
.page-exchange-rules .text-content{
    padding: 0px 0 15px 0;
    background: #0C1220;
}
.page-exchange-rules .text-content h3{
    margin: 25px 0 15px 15px;
    color: #bacef1;
    font-size: 15px;
    font-weight: bold;
}
.page-exchange-rules .text-content .content{
    color: #BACEF1;
    font-size: 12px;
    padding: 0 15px 0 15px;
}

.content ul li{
    list-style: none;
    padding: 3px 0;
    color: #4f6282;
}
</style>
