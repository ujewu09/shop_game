<template>
  <div class="page-exchange">
    <component-header>
      <template #left>
        <img @click="$router.go(-1)" src="./../assets/images/icon_back.png" />
      </template>
      <template #title>
        我的兑换
      </template>
      <template #right>
          <img  @click="$router.push({path: 'exchangeRules'})" src="./../assets/images/xuanxuan-image.png" />
           <img @click="$router.push({path: 'customer'})" src="./../assets/images/headset.png" />
      </template>
    </component-header>

    <div class="tab">
      <van-tabs
        class="tabs"
        v-model="active"
        swipeable
        title-active-color="#FFFFFF"
        title-inactive-color="#95A5C4"
        :sticky="true"
        color="#28FFD4"
        :border="false"
        background="#0C1220"
        line-width="28"
        @change="onChange"
        offset-top="46"
      >
        <!-- <span
            style="
            font-size:14px;
            text-align: center;
            display:inline-block;
            width:23px;
            height:23px;
            line-height:26px;
            border-radius:50%
            color: #B8CCEF;
            background-color: #21263B;"
            @click="$router.go(-1)"
        ><van-icon name="arrow-left" color="#fff" /></span>-->
        <van-tab v-for="itemp in list" :key="itemp.id" :name="itemp.id" :title="itemp.text">
          <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
            <van-list
              v-if="empty != true"
              v-model="upLoading"
              :finished="finished"
              finished-text="已经到底了"
              @load="onLoad"
            >
              <div class="tabListContent" v-show="itemp.id == active">
                <van-row ref="rowList" gutter="8">
                  <van-col v-for="item in listContent" :key="item.id" span="24">
                    <div class="card">
                      <div @click="onOrderDetails(item)">
                        <div class="row1">
                          <span class="date-time">{{item.updated_at}}</span>
                          <span class="status">
                            {{
                            item.status == 0 && "兑换中" ||
                            item.status == 1 && "待发货" ||
                            item.status == 2 && "已发货" ||
                            item.status == 3 && "已完成" ||
                            item.status == 4 && "已取消"
                            }}
                          </span>
                        </div>
                        <div class="row2">
                          <div class="image">
                            <van-image width="50" height="50" :src="item.goods_thumb_img">
                              <template v-slot:loading>
                                <van-loading type="spinner" size="20" />
                              </template>
                              <template v-slot:error>
                                <img style="max-width: 100%" src="../assets/images/error-image.png" />
                              </template>
                            </van-image>
                          </div>
                          <div class="textContext">
                            <div class="text">{{item.goods_name}}</div>
                            <div class="num">×1</div>
                          </div>
                        </div>
                      </div>
                      <div class="row3">
                        <div class="order-num">
                          <b>订单号</b>：<span class="span">{{item.order_sn}}</span>&nbsp;
                          <span
                            v-clipboard:copy="item.order_sn"
                            v-clipboard:success="onCopy"
                            v-clipboard:error="onError"
                            style="color:#FFFFFF;margin-left:5px"
                          >
                            <van-image
                              width="12"
                              :src="require('../assets/images/Icon_copy_xiao.png')"
                            />
                          </span>
                        </div>
                        <div class="currency"><span style="font-size: 15px;color:#1de7e7">{{item.price}}</span>&nbsp;
                          <span style="color:bacef1">竞猜币</span>
                        </div>
                      </div>
                      <div class="row4">
                        <van-button
                          @click="goPay(item)"
                          v-if="itemp.id == 0"
                          plain
                          hairline
                          type="primary"
                          class="btn-payment"
                        >去支付</van-button>
                        <van-button @click="goPay(item, 'againPay')" v-else plain hairline type="primary">再次兑换</van-button>
                      </div>
                    </div>
                  </van-col>
                </van-row>
              </div>
            </van-list>
          </van-pull-refresh>
          <div v-if="empty" class="empty">
            <van-empty
              class="empty-image"
              description="兑换记录列表为空"
              :image="require('../assets/images/books.png')"
            />
            <van-button plain hairline @click="$router.push({ path: 'index' })">去兑换</van-button>
          </div>
        </van-tab>
      </van-tabs>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { Toast, Empty, PullRefresh } from "vant";
import ComponentHeader from './../components/ComponentHeader';
import axios from "axios";
Vue.use(Empty);
Vue.use(PullRefresh);
export default {
  components: {
    ComponentHeader
  },
  data() {
    return {
      active: -1,
      list: [
        { id: -1, text: "全部" },
        { id: 0, text: "兑换中" },
        { id: 1, text: "待发货" },
        { id: 2, text: "已发货" },
        { id: 3, text: "已完成" }
      ],
      listContent: [],
      downLoading: false,
      upLoading: false,
      finished: false,
      currentStatusID: -1,
      empty: false,
      pages: {
        page: {},
        limit: 12
      }
    };
  },
  created() {
    if (this.$route.query && this.$route.query.active != undefined) {
      this.active = Number(this.$route.query.active);
      this.currentStatusID = this.active;
    }
  },
  mounted() {

  },
  methods: {
    onCopy() {
      Toast("复制成功!");
    },
    onError() {
      Toast("复制失败!");
    },
    onClickRight() {
      Toast("按钮");
    },
    goPay(data, status) {
      this.$router.push({
        path: "paymentDetails",
        query: {
          order_sn: data.order_sn,
          type: "pay",
          status: status
        }
      });
    },
    onOrderDetails(data) {
      // 订单详情
      this.$router.push({
        path: "paymentDetails",
        query: {
          order_sn: data.order_sn
        }
      });
    },
    onChange(ID) {
      this.upLoading = true;
      this.finished = false;
      this.listContent = [];
      this.currentStatusID = ID;
      this.pages.page["page" + this.currentStatusID] = 1;
      this.getOrderList({
        page: this.pages.page["page" + this.currentStatusID],
        limit: this.pages.limit,
        status: this.currentStatusID
      });
      this.minHeight();
    },
    onRefresh() {
      this.pages.page["page" + this.currentStatusID] = 1;
      this.finished = false;
      this.getOrderList(
        {
          page: this.pages.page["page" + this.currentStatusID],
          limit: this.pages.limit,
          status: this.currentStatusID
        },
        () => {
          this.listContent = [];
          this.downLoading = false;
        }
      );
    },
    onLoad() {
      //异步更新数据
      if (this.pages.page["page" + this.currentStatusID]) {
        this.pages.page["page" + this.currentStatusID] += 1;
      } else {
        this.pages.page["page" + this.currentStatusID] = 1;
      }
      this.getOrderList({
        page: this.pages.page["page" + this.currentStatusID],
        limit: this.pages.limit,
        status: this.currentStatusID
      });
      this.minHeight();
    },
    getOrderList(obj, callback) {
      axios.post(this.config.HOST + "api/order/list", obj).then(response => {
        if (callback) {
          callback(result);
        }
        let result = response.data;
        if (result.code == 0) {
          let { data } = result;
          if (data.length > 0) {
            this.upLoading = false;
            this.finished = false;
            this.listContent = this.listContent.concat(data);
          } else {
            this.upLoading = true;
            this.finished = true;
          }
          if (data.length == 0 && obj.page == 1) {
              this.empty = true;
          } else {
              this.empty = false;
          }
        } else {
          this.upLoading = true;
          this.finished = true;
        }

      });
    },
    minHeight() {
      // 设置列表内容最小高度
      let clearTabList = setInterval(() => {
        let con = this.$refs.rowList
        if (con.length > 0 && con[0].$el) {
          con.map(item => {
            item.$el.style.minHeight = (window.screen.height - 180) + "px";
          })
          clearInterval(clearTabList);
        }
      }, 100);
    },
  }
};
</script>
<style lang="less" scoped>
.page-exchange {
  /* 导航 */
  min-height: 100%;
  .nav-row {
    .nav {
      color: #ffffff;
      background-color: #090c15;
      .van-ellipsis {
        color: #ffffff !important;
      }
      .title {
        color: #bacef1 !important;
      }
    }
  }

  /* tab */
  .tab {
    // position: relative;
    // top: 46px;
    // text-align: left;
    background-color: #0c1220;
    // min-height: 100%;
    // height: 100%;

    // 强制修改组件内部样式
    ::v-deep 
    {
        .van-sticky {
            background-color: #0c1220;
            padding: 0 15px;
            border-bottom: 1px solid #333c4e;
        }
        [role="tab"] {
            font-size: 13px;
        }
        [aria-selected="true"] {
            font-weight: bold;
            font-size: 15px;
        }
        .van-list__finished-text, .van-list__loading *, .van-pull-refresh__head *{
            color: #526583;
            font-size: 12px;
        }
        .van-tab:nth-child(1){
            position: relative;
            flex: auto !important;
            max-width: 100px;
            min-width: 81px;
            &::after {
              position: absolute;
              top: 0%;
              left: 0;
              content: '';
              height: 20px;
              width: 1px;
              background: #0c1220;
              transform: translateY(-50%);
            }
        }
        .van-tab{
            position: relative;
            flex: auto !important;
            max-width: 100px;
            min-width: 81px;
            &::after {
              position: absolute;
              top: 50%;
              left: 0;
              content: '';
              height: 20px;
              width: 1px;
              background: #333c4e;
              transform: translateY(-50%);
            }
            .van-tab__text--ellipsis{
              color: #bacef1;
            }
        }
    }

    .van-sticky--fixed {
      top: 46px !important;
    }
    .tabListContent {
      padding: 2px 12px 0 12px;
    }
    .van-tabs .van-tabs__line {
      background-color: #03d1de;
    }
    .card {
      margin: 8px 0 0 0;
      /* padding: 12px; */
      text-align: left;
      position: relative;
      color: #ffffff;
      border-radius: 5px;
      background-color: #1d2538;
      .row1 {
        padding: 15px;
        .date-time {
          font-size: 12px;
          color: #4f6282;
        }
        .status {
          float: right;
          font-size: 13px;
          text-align: right;
          font-weight: bold;
          color: #bacef1;
        }
      }

      .row2 {
        display: flex;
        align-items: center;
        overflow: hidden;
        margin: 0 15px;
        box-sizing: border-box;
        .textContext {
          flex: 1;
          .text {
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            color: #ffffff;
            width: 60%;
            font-weight: bold;
          }
          .num {
            color: #bacef1;
            font-weight: bold;
          }
          .text,
          .num {
            font-size: 13px;
            padding: 5px 0px 5px 15px;
          }
        }
        &::v-deep .van-image__error {
          background: none;
        }
      }

      .row3 {
        display: flex;
        padding: 15px 15px 10px 15px;
        border-bottom: 1px solid #262f40;
        .order-num {
          flex: 1;
          font-size: 12px;
          font-weight: bold;
          color: #4f6282;
        }
        .span{
          font-weight: 100;
        }
        .currency {
          color: #bacef1;
          font-size: 12px;
        }
      }

      .row4 {
        display: flex;
        flex-direction: row-reverse;
        padding: 10px 15px 15px 0;
        .van-button {
          width: 80px;
          border: 1px solid #2f3950;
          border-style:none;
          border-radius: 6px;
          background-color: rgba(0, 0, 0, 0);
          height: 30px;
          color: #00b3f1;
          font-weight: bold;
          font-size: 14px;
          padding: 0;
        }
        .btn-payment.van-button {
          border-style:none;
          border: transparent;
          color: #ffffff;
          font-weight: bold;
          border-radius: 6px;
          background-image: linear-gradient(90deg, #00cbdc, #00a4f6);
        }
      }
    }
  }

  /* 数据状态为空 */
  .empty {
    text-align: center;
    button {
      width:91px;
      background: transparent;
      border: 1px solid #2f3950;
      border-radius: 6px;
      color: #1bafff;
      height: 29px;
      font-size: 14px;
      padding: 0;
    }
    .van-empty{
        padding-bottom: 37.5px;
        padding-top:104px;
    }
    .empty-image ::v-deep .van-empty__image {
      padding-top: 25px;
      width: 90px !important;
      height: auto;
    }
    .empty-image ::v-deep .van-empty__description {
      font-size: 12px;
      color: #4f6282;
      margin: 16.5px 0 0 0;
    }
  }
}
</style>
