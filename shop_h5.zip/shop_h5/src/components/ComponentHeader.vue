<template>
    <div class="component-header">
        <van-nav-bar fixed z-index="1000" class="header" :border="false">
            <template #left>
                <div class="left">
                    <slot name="left"></slot>
                </div>
            </template>
            <template #title>
                <span class="title">
                    <slot name="title"></slot>
                </span>
            </template>
            <template #right>
                <div class="right">
                    <slot name ="right"></slot>
                    <!-- <img @click="$router.push({path: 'exchangeRules'})" src="./../assets/images/xuanxuan-image.png" />
                    <img @click="$router.push({path: '/exchange'})" src="./../assets/images/xuanxuan-image2.png" /> -->
                </div>
            </template>
        </van-nav-bar>
    </div>
</template>
<style lang="less">
    .component-header {
        .header {
            display: flex;
            justify-content: space-around;
            background-color: #090C15;
            .title {
                color: #BACEF1;
                font-weight: bold;
            }
            .left {
                img {
                    width: 21px;
                }
            }
            .right {
                padding: 0 6.5px 0 0;
                opacity: 1;
                img {
                    opacity: 1;
                    width: 21px;
                    &:first-child {
                        width: 21px;
                    }
                }
                img:nth-of-type(2){
                    margin:0 0 0 16.5px;
                }
            }
            .van-nav-bar__right:active{
                opacity: 1;
            }
        }
    }
</style>