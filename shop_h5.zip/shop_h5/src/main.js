import Vue from 'vue'
import App from './App.vue'

// false 为关闭某些信息提示
Vue.config.productionTip = false
import router from './router/index.js';
import config from './config.js';
import utils from './utils/common.js';
import axios from 'axios';
import './assets/style/style.less';
import { Notify, Dialog } from 'vant';
Vue.use(Notify);
Vue.use(Dialog);
Vue.prototype.config = config;
Vue.prototype.utils = utils;

// 路由跳转前
router.beforeEach((to, from, next) => {
    let uriIndex = to.fullPath.indexOf("?");
    let uri = to.fullPath.substring(0, uriIndex != -1 ? uriIndex : to.fullPath.length);

    // 更新竞猜币和今日可兑换次数
    if (uri == "/index" || to.query.session) {
        utils.userInfo(to.query.session).then((response) => {
            let { data } = response;
            if (data.code == 0) {
                Vue.prototype.config.PRICE = data.data.gold;
                Vue.prototype.config.COUNT = data.data.num;
            }
        });
    }

    // 存储过去到的session数据
    if (to.query.session) {
        sessionStorage.setItem("session", to.query.session);
        next();
        return;
    } else {
        if (uri == '/index' || uri == '/exchangeRules' || uri == '/productDetails') {
            next();
            return;
        }else if (sessionStorage.getItem("session")) {
            next();
            return;
        } else {
            window.dispatchEvent(new CustomEvent('eventNoLogin'))
        }
    }
    
});

// 拦截器
axios.interceptors.request.use((config) => {
    // 请求拦截
    // 默认添加参数session
    if (sessionStorage.getItem("session")) {
        config.data.session = sessionStorage.getItem("session");
    }
    return config;
});

Vue.prototype.$http = axios;
axios.defaults.crossDomain = true;
axios.interceptors.response.use((response) => {
    if (response && response.data) {
        // 处理错误提示
        if (response.data.code != 0 && response.data.code != 200 && sessionStorage.getItem("session")) {
            Notify({ type: 'danger', message: response.data.msg , className: 'auto-notify'});
        }
        return response;
    } else {
        return response;
    }
}, function (error) {
    return Promise.reject(error);
});

function getQueryVariable(variable) {
    var query = window.location.href.substring(window.location.href.indexOf("?") + 1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) { return pair[1]; }
    }
    return (false);
}
let session = getQueryVariable("session");
if (session == false) {
    sessionStorage.clear();
}
new Vue({
    router,
    render: h => h(App),
}).$mount('#app')
