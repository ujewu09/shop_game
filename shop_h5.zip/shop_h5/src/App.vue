<template>
  <div id="app" v-if="loadSuccess" v-bind:style="{height: maxHeight}">
    <div class="content">
      <router-view />
    </div>
    <van-overlay :show="noLogin" z-index="1000">
      <div class="no-login">
        <div class="block">
          你还未登录，请先登录再进行查看
        </div>
      </div>
    </van-overlay>
  </div>
</template>

<script>
import Vue from 'vue';
import VueClipboard from 'vue-clipboard2'
import { NavBar,Icon,Tab, Tabs, List, Col, Row, Image as VanImage, Button,Card, Notify } from 'vant';
Vue.use(NavBar);
Vue.use(Icon);
Vue.use(Tab);
Vue.use(Tabs);
Vue.use(List);
Vue.use(Col);
Vue.use(Row);
Vue.use(VanImage);
Vue.use(Button);
Vue.use(Card);
Vue.use(Notify);
VueClipboard.config.autoSetContainer = true
Vue.use(VueClipboard)

export default {
  name: 'App',
  data() {
        return {
            loadSuccess: false,
            maxHeight: 0,
            noLogin: false,
        };
    },
    mounted(){
        this.loadSuccess = true;
        this.maxHeight = window.innerHeight + 'px';
        window.addEventListener("eventNoLogin", () => { 
          this.noLogin=true;
          setTimeout(() => {
            this.noLogin = false;
          }, 2000);
        })
    }
}

</script>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  /* color: #2c3e50; */
  background-color: #0C1220;
  & > .content {
    padding-top: 45px;
  }
          
  @font-face {
      font-family: FontRegular;
      src: url(./assets/font/FontRegular.ttf);
  }
  font-family: FontRegular;
}

.no-login {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  .block {
    color: #bacef1;
    background: #222d41;
    padding: 10px 15px;
    font-size: 14px;
    border-radius: 5px;
  }
}

.auto-notify {
  padding: 8px 40px;
  padding-left: 57px;
  &::before{
    position: absolute;
    width: 20px;
    height: 100%;
    content: "";
    background-image: url(./assets/images/error.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: top center;
    margin-left: -20px;
  }
}


</style>
