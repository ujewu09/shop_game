import axios from 'axios';
import config from '../config.js';
function userInfo(session) {
    // 获取用户信息
    if (session) {
        axios.post(config.HOST + "api/user/info", { user_type: 1 });
    }
    return axios.post(config.HOST + "api/user/info", {});
}

function filterPrice(num) {
    return (num || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
}

export default {
    userInfo,
    filterPrice
}