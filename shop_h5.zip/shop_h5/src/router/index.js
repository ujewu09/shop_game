import Vue from 'vue'
import Router from 'vue-router'  // 引入vue-router


// 引入要跳转的vue组件
import Index from '@/pages/index';
import Exchange from '@/pages/exchange';
import ProductDetails from '@/pages/productDetails';
import Payment from '@/pages/payment';
import List from '@/pages/list';
import ExchangeRules from '@/pages/exchangeRules';
import PaymentDetails from '@/pages/paymentDetails';
import Customer from '@/pages/customer';
Vue.use(Router)  // 在vue中注入Router
// 配置路由路径
const routes = [
    {
        path: '/',
        name: '主页',
        redirect: '/index'
    },
    {
        path: '/index',
        name: 'Index',
        component: Index  // 需要跳转的组件
    },
    {
        path: '/exchange',
        name: 'Exchange',
        component: Exchange  // 需要跳转的组件
    },
    {
        path: '/productDetails',
        name: 'productDetails',
        component: ProductDetails  // 需要跳转的组件
    },
    {
        path: '/payment',
        name: 'Payment',
        component: Payment  // 需要跳转的组件
    },
    {
        path: '/list',
        name: 'List',
        component: List  // 需要跳转的组件
    },
    {
        path: '/exchangeRules',
        name: 'ExchangeRules',
        component: ExchangeRules  // 需要跳转的组件
    },
    {
        path: '/paymentDetails',
        name: 'PaymentDetails',
        component: PaymentDetails  // 需要跳转的组件
    },
    {
        path: '/customer',
        name: 'Customer',
        component: Customer  // 需要跳转的组件
    },
]

// 将路径注入到Router中
var router = new Router({
    // 'mode': 'history',
    routes
});

// 导出路由
export default router;